Squads were prepared by PlayStation Pulse Team

Main channel: https://t.me/PlayStation_Pulse

Chat: https://t.me/PSPulse_Discuss

How Update Squads FC 26 on PS4: https://t.me/PlayStation_Pulse/796

How Update Squads FC 26 on PS4 (Video): https://t.me/PlayStation_Pulse/679

How Update Squads FC 26 on PS5: https://t.me/PlayStation_Pulse/397

How Install Assets DLC for FC 26 on PS4: https://t.me/PlayStation_Pulse/800

——————————————————————————————————————————————

Credits:

BlackArch
https://t.me/sudoBlackArch